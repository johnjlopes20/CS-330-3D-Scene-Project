///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// Manage the loading and rendering of 3D scenes
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <iostream>
#include <glm/gtx/transform.hpp>

// Declaration of global variables
namespace {
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";

    // Define directional light properties
    glm::vec3 g_LightDirection = glm::normalize(glm::vec3(-0.5f, -1.0f, -0.5f)); // Example direction
    glm::vec3 g_LightColor = glm::vec3(1.0f, 1.0f, 1.0f); // White light
    float g_AmbientStrength = 0.3f;
    float g_SpecularStrength = 0.5f;
    float g_Shininess = 32.0f;
}

/***********************************************************
 * SceneManager()
 *
 * The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager) {
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 * ~SceneManager()
 *
 * The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager() {
    m_pShaderManager = nullptr;
    delete m_basicMeshes;
    m_basicMeshes = nullptr;
}

/***********************************************************
 * CreateGLTexture()
 *
 * This method is used for loading textures from image files,
 * configuring the texture mapping parameters in OpenGL,
 * generating the mipmaps, and loading the read texture into
 * the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag) {
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    // Indicate to always flip images vertically when loaded
    stbi_set_flip_vertically_on_load(true);

    // Try to parse the image data from the specified image file
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    // If the image was successfully read from the image file
    if (image) {
        std::cout << "Successfully loaded image: " << filename << ", width: " << width << ", height: " << height << ", channels: " << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // Set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // Set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // Determine the format of the loaded image data
        GLenum format = (colorChannels == 3) ? GL_RGB : GL_RGBA;

        // Load the texture into OpenGL
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, image);

        // Generate the texture mipmaps
        glGenerateMipmap(GL_TEXTURE_2D);

        // Free the image data from local memory
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        // Register the loaded texture and associate it with the special tag string
        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    std::cerr << "Could not load image: " << filename << std::endl;

    // Error loading the image
    return false;
}

/***********************************************************
 * BindGLTextures()
 *
 * This method is used for binding the loaded textures to
 * OpenGL texture memory slots. There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures() {
    for (int i = 0; i < m_loadedTextures; i++) {
        // Bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 * DestroyGLTextures()
 *
 * This method is used for freeing the memory in all the
 * used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures() {
    for (int i = 0; i < m_loadedTextures; i++) {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 * FindTextureID()
 *
 * This method is used for getting an ID for the previously
 * loaded texture bitmap associated with the passed-in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag) {
    for (int i = 0; i < m_loadedTextures; i++) {
        if (m_textureIDs[i].tag == tag) {
            return m_textureIDs[i].ID;
        }
    }
    return -1; // Not found
}

/***********************************************************
 * FindTextureSlot()
 *
 * This method is used for getting a slot index for the previously
 * loaded texture bitmap associated with the passed-in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag) {
    for (int i = 0; i < m_loadedTextures; i++) {
        if (m_textureIDs[i].tag == tag) {
            return i;
        }
    }
    return -1; // Not found
}

/***********************************************************
 * FindMaterial()
 *
 * This method is used for getting a material from the previously
 * defined materials list that is associated with the passed-in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material) {
    for (const auto& mat : m_objectMaterials) {
        if (mat.tag == tag) {
            material = mat;
            return true;
        }
    }
    return false; // Not found
}

/***********************************************************
 * SetTransformations()
 *
 * This method is used for setting the transform buffer
 * using the passed-in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(glm::vec3 scaleXYZ, float XrotationDegrees, float YrotationDegrees, float ZrotationDegrees, glm::vec3 positionXYZ) {
    glm::mat4 modelView;
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (m_pShaderManager != nullptr) {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 * SetShaderColor()
 *
 * This method is used for setting the passed-in color
 * into the shader for the next draw command.
 ***********************************************************/
void SceneManager::SetShaderColor(float redColorValue, float greenColorValue, float blueColorValue, float alphaValue) {
    glm::vec4 currentColor = glm::vec4(redColorValue, greenColorValue, blueColorValue, alphaValue);

    if (m_pShaderManager != nullptr) {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 * SetShaderTexture()
 *
 * This method is used for setting the texture data
 * associated with the passed-in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag) {
    if (m_pShaderManager != nullptr) {
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int textureID = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
    }
}

/***********************************************************
 * SetTextureUVScale()
 *
 * This method is used for setting the texture UV scale
 * values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v) {
    if (m_pShaderManager != nullptr) {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 * SetShaderMaterial()
 *
 * This method is used for passing the material values
 * into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag) {
    if (m_pShaderManager != nullptr && m_objectMaterials.size() > 0) {
        OBJECT_MATERIAL material;

        // Attempt to find the material associated with the tag
        if (FindMaterial(materialTag, material)) {
            // Set material properties in the shader
            m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
            m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
        else {
            std::cerr << "Material with tag '" << materialTag << "' not found." << std::endl;
        }
    }
    else {
        std::cerr << "ShaderManager or material list not initialized or empty." << std::endl;
    }
}

/***********************************************************
 * PrepareScene()
 *
 * This method is used for preparing the 3D scene by loading
 * the shapes, textures in memory to support the 3D scene
 * rendering.
 ***********************************************************/
void SceneManager::PrepareScene() {
    bool success = true;

    // Load rusticwood texture
    success &= CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "rusticwood_tag");

    // Load circular brushed gold texture
    success &= CreateGLTexture("../../Utilities/textures/circular-brushed-gold-texture.jpg", "circular_brushed_gold_tag");

    if (success) {
        std::cout << "Textures loaded successfully." << std::endl;
        BindGLTextures(); // Bind all loaded textures after successful loading
    }
    else {
        std::cerr << "Failed to load one or more textures." << std::endl;
    }
}

/***********************************************************
 * RenderScene()
 *
 * This method renders the 3D scene, including the mug with
 * a rusticwood texture for the body and a circular brushed gold texture for the plane.
 ***********************************************************/
void SceneManager::RenderScene() {
    // Clear any previous settings
    m_pShaderManager->setIntValue(g_UseLightingName, true);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Enable lighting in the shader
    m_pShaderManager->setIntValue(g_UseLightingName, true);

    // Set directional light properties
    m_pShaderManager->setVec3Value("dirLight.direction", g_LightDirection);
    m_pShaderManager->setVec3Value("dirLight.color", g_LightColor);

    // Set material properties (for the plane and the mug body)
    m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f, 1.0f, 1.0f));
    m_pShaderManager->setFloatValue("material.ambientStrength", 0.3f);
    m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f, 1.0f, 1.0f));
    m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f, 1.0f, 1.0f));
    m_pShaderManager->setFloatValue("material.shininess", 32.0f);


    // Render the plant pot (tapered cylinder)
    {
        // Set material properties for the plant pot
        m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(0.8f, 0.5f, 0.2f));
        m_pShaderManager->setFloatValue("material.ambientStrength", 0.3f);
        m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(0.8f, 0.5f, 0.2f));
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f, 1.0f, 1.0f));
        m_pShaderManager->setFloatValue("material.shininess", 32.0f);

        // Set transformations for the plant pot
        glm::vec3 potScale = glm::vec3(1.5f, 1.0f, 1.5f);
        float potRotation = 0.0f;
        glm::vec3 potPosition = glm::vec3(-5.0f, 0.0f, 0.0f);
        SetTransformations(potScale, potRotation, potRotation, potRotation, potPosition);

        // Set color for the plant pot
        SetShaderColor(0.8f, 0.5f, 0.2f, 1.0f); // Color brown

        // Load and render the tapered cylinder (plant pot)
        m_basicMeshes->LoadTaperedCylinderMesh();
        m_basicMeshes->DrawTaperedCylinderMesh();
    }



    // Render the mug body (cylinder) with rusticwood texture
    {
        // Set transformations for the mug body (cylinder)
        glm::vec3 mugScale = glm::vec3(2.0f);
        float rotationAngle = 0.0f;
        glm::vec3 mugPosition = glm::vec3(0.0f);
        SetTransformations(mugScale, rotationAngle, rotationAngle, rotationAngle, mugPosition);

        // Set texture for the mug body (rusticwood texture)
        SetShaderTexture("rusticwood_tag");
        m_basicMeshes->LoadCylinderMesh(); // Ensure cylinder mesh is loaded
        m_basicMeshes->DrawCylinderMesh(); // Draw the cylinder (mug body)
    }

    // Render a colored plane mesh with circular brushed gold texture
    {
        // Set transformations for the plane mesh
        glm::vec3 planeScale = glm::vec3(20.0f, 10.0f, 10.0f);
        glm::vec3 planePosition = glm::vec3(0.0f, -1.0f, 0.0f);
        SetTransformations(planeScale, 0.0f, 0.0f, 0.0f, planePosition);

        // Set texture for the plane mesh (circular brushed gold texture)
        SetShaderTexture("circular_brushed_gold_tag");

        m_basicMeshes->LoadPlaneMesh();
        m_basicMeshes->DrawPlaneMesh();
    }


    // Render the plant leaves using cones
    {
        // Set material properties for the leaves
        m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(0.2f, 0.6f, 0.2f));
        m_pShaderManager->setFloatValue("material.ambientStrength", 0.3f);
        m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(0.2f, 0.6f, 0.2f));
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f, 1.0f, 1.0f));
        m_pShaderManager->setFloatValue("material.shininess", 32.0f);

        // Set color for the leaves (if not using textures)
        SetShaderColor(0.2f, 0.6f, 0.2f, 1.0f); // Example color (green)

        // Ensure cone mesh is loaded
        m_basicMeshes->LoadConeMesh();

        // Draw two elongated leaves using cones
        for (int i = 0; i < 2; ++i)
        {
            // Set transformations for each leaf (adjust scale and position as needed)
            glm::vec3 leafScale = glm::vec3(0.2f, 1.2f, 0.2f); // Elongated scale of the leaf
            float leafRotation = 0.0f; // Rotation angle of the leaf
            glm::vec3 leafPosition = glm::vec3(-5.50f + i * 0.8f, 1.0f, 0.0f);

            SetTransformations(leafScale, leafRotation, leafRotation, leafRotation, leafPosition);

            // Debug output
            std::cout << "Rendering leaf " << i << " at position: " << leafPosition.x << ", " << leafPosition.y << ", " << leafPosition.z << std::endl;

            // Load and draw the leaf mesh using a cone
            m_basicMeshes->DrawConeMesh();
        }
    }


    // Render the branded laptop (box)
    {
        // Set material properties for the laptop
        m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(0.3f, 0.3f, 0.3f));
        m_pShaderManager->setFloatValue("material.ambientStrength", 0.3f);
        m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(0.5f, 0.5f, 0.5f));
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.7f, 0.7f, 0.7f));
        m_pShaderManager->setFloatValue("material.shininess", 64.0f);

        // Set transformations for the laptop (box)
        glm::vec3 laptopScale = glm::vec3(3.0f, 0.2f, 1.5f);
        float laptopRotation = 0.0f;
        glm::vec3 laptopPosition = glm::vec3(7.0f, 0.0f, 0.0f);
        SetTransformations(laptopScale, laptopRotation, laptopRotation, laptopRotation, laptopPosition);

        // Set texture for the laptop (branding with "SONY" logo or texture)
        SetShaderTexture("sony_logo_texture_tag");

        // Load and render the box (laptop)
        m_basicMeshes->LoadBoxMesh();
        m_basicMeshes->DrawBoxMesh();
    }


    // Render the pen
    {
        // Set material properties for the pen body
        m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(0.2f, 0.2f, 0.2f));
        m_pShaderManager->setFloatValue("material.ambientStrength", 0.3f);
        m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(0.1f, 0.1f, 0.8f)); // Blue color for the pen body
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.7f, 0.7f, 0.7f));
        m_pShaderManager->setFloatValue("material.shininess", 32.0f);

        // Set transformations for the pen body (cylinder)
        glm::vec3 penScale = glm::vec3(0.08f, 0.5f, 0.08f);
        float penRotation = glm::radians(90.0f);
        glm::vec3 penPosition = glm::vec3(5.0f, 0.0f, 0.0f);
        SetTransformations(penScale, penRotation, penRotation, penRotation, penPosition);

        // Draw the cylinder (pen body)
        m_basicMeshes->LoadCylinderMesh();
        m_basicMeshes->DrawCylinderMesh();

        // Render the pen cap
        {
            // Set transformations for the pen cap 
            glm::vec3 capScale = glm::vec3(0.1f, 0.02f, 0.1f);
            glm::vec3 capPosition = glm::vec3(5.0f, 0.25f, 0.0f);

            // Set transformations for the cap
            SetTransformations(capScale, penRotation, penRotation, penRotation, capPosition);

            // Set color for the cap (red color)
            SetShaderColor(0.8f, 0.1f, 0.1f, 1.0f);

            // Draw the box (pen cap)
            m_basicMeshes->LoadBoxMesh();
            m_basicMeshes->DrawBoxMesh();
        }

        // Render the pen clip 
        {
            // Set transformations for the pen clip 
            glm::vec3 clipScale = glm::vec3(0.04f, 0.04f, 0.08f);
            glm::vec3 clipPosition = glm::vec3(5.0f, 0.35f, 0.0f);

            // Set transformations for the clip
            SetTransformations(clipScale, penRotation, penRotation, penRotation, clipPosition);

            // Set color for the clip (silver or metallic)
            SetShaderColor(0.8f, 0.8f, 0.8f, 1.0f);

            // Draw the box (pen clip)
            m_basicMeshes->LoadBoxMesh();
            m_basicMeshes->DrawBoxMesh();
        }

        // Render the pen tip
        {
            // Set transformations for the pen tip 
            glm::vec3 tipScale = glm::vec3(0.06f, 0.03f, 0.06f);
            glm::vec3 tipPosition = glm::vec3(5.0f, -0.25f, 0.0f);

            // Set transformations for the tip
            SetTransformations(tipScale, penRotation, penRotation, penRotation, tipPosition);

            // Set color for the tip (dark grey or black)
            SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);

            // Draw the cylinder (pen tip)
            m_basicMeshes->LoadCylinderMesh();
            m_basicMeshes->DrawCylinderMesh();
        }
    }



    // Reset to default settings
    m_pShaderManager->setIntValue(g_UseTextureName, false);
    m_pShaderManager->setIntValue(g_UseLightingName, true);
}